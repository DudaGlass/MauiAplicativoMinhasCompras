﻿using MauiAppMinhasCompras.Models; // estamos usando a nossa Model de Produto
using SQLite; // estamos usando 

namespace MauiAppMinhasCompras.Helpers
{
    public class SQLiteDatabaseHelper // mudamos o INTERNAL para Public para que seja acessivel em outras partes do projeto
    {
        readonly SQLiteAsyncConnection _conn; // campo de somente leitura, aprendemos isso na agenda 
        // conn e sempre chamado usamos ele porque ele e sempre que o objeto e instanciado 

        public SQLiteDatabaseHelper(string path)  
        { 
            _conn = new SQLiteAsyncConnection(path); // ele vai ser uma conexao com o arquivo de texto
                                                     // eu falo onde  esta o arquivo e a classe SQLiteAsyncConnection abre o arquivo
            _conn.CreateTableAsync<Produto>().Wait(); // criamos a tabela produto 
        }

        public Task<int> Insert(Produto p) // parametro P, tipo produto 
        {
            return _conn.InsertAsync(p); // estou acessando a memoria de um arquivo, 
        }

        public Task<List<Produto>> Update(Produto p) 
        {
            string sql = "UPDATE Produto SET Descricao=?, Quantidade=?, Preco=? WHERE Id=?";

            return _conn.QueryAsync<Produto>(
                sql, p.Descricao, p.Quantidade, p.Preco, p.Id
            );
        }

        public Task<int> Delete(int id) 
        {
            return _conn.Table<Produto>().DeleteAsync(i => i.Id == id); // vou deletar onde ? 
        }

        public Task<List<Produto>> GetAll() 
        {
            return _conn.Table<Produto>().ToListAsync(); // chamamos a tabela de produto, onde eu quero todo mundo
        }

        public Task<List<Produto>> Search(string q) // Pesquisar produtos no banco de dados pelo nome ou uma descrição
        {
            string sql = "SELECT * Produto WHERE descricao LIKE '%" + q + "%'";

            return _conn.QueryAsync<Produto>(sql);
        }
    }
}
