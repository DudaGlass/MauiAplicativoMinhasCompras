﻿using SQLite; // adicionamos a USING do SQLite

namespace MauiAppMinhasCompras.Models
{
    public class Produto // Mudamos de INTERNAL para Public
    {
        // Declaramos as propriedades do nosso produto 
        [PrimaryKey, AutoIncrement] 
        public int Id { get; set; }
        public string Descricao { get; set; }
        public double Quantidade {  get; set; }
        public double Preco {  get; set; }
    }
}
