﻿using MauiAppMinhasCompras.Helpers;

namespace MauiAppMinhasCompras
{
    public partial class App : Application
    {
        static SQLiteDatabaseHelper _db; //declarar um campo Static, 
         
        public static SQLiteDatabaseHelper Db // para chegar dentro do banco DB, eu preciso passar por uma propriedde publica
        {
            get
            {
                if(_db == null) // verifico se eu ja tenho um objeto dentro do banco
                {
                    string path = Path.Combine( // declarando uma variavel string pathpara armazenar o caminho do banco de dados
                                                // COMBINE garante que idependente do caminho eu encontre o caminho completo
                        Environment.GetFolderPath( // GetFolderPath pega informacoes de uma paasta ou caminho
                            Environment.SpecialFolder.LocalApplicationData), // onde vai conter os arquivos da minha aplicacao
                        "banco_sqlite_compras.db3"); // aqui eu passo o nome do arquivo 

                    _db = new SQLiteDatabaseHelper(path); 
                }

                return _db; // sempre que eu chamar o campo Db
            }
        }

        public App()
        {
            InitializeComponent();

            //MainPage = new AppShell(); //para tela inicial
            MainPage = new NavigationPage(new Views.ListaProduto()); // tela de navegacao
        }
    }
}
